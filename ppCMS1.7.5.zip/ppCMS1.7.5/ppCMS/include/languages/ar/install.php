<?php

/*

Want to help translate AktifBoxCms?
Then check out http://ptrans.wikyblog.com/pt/AktifBoxCms 

*/

global $langmessage;

$langmessage['Checking_server']	= 'Checking server';
$langmessage['Installation']	= 'Installation';
$langmessage['Checking']		= 'Checking';
$langmessage['Status']			= 'الحالة';
$langmessage['Current_Value']	= 'Current Value';
$langmessage['Expected_Value']	= 'Expected Value';
$langmessage['PHP_Version']		= 'PHP Version';
$langmessage['Failed']			= 'Failed';
$langmessage['Passed']			= 'Passed';
$langmessage['Set']				= 'Set';
$langmessage['Not_Set']			= 'Not Set';
$langmessage['See_Below']		= 'See Below';
$langmessage['On']				= 'مضاء';
$langmessage['Off']				= 'مطفأ';
$langmessage['Refresh']			= 'Refresh';
$langmessage['Install']			= 'التثبيت';
$langmessage['Installing']		= 'Installing';
$langmessage['Continue']		= 'متابعة';
$langmessage['configuration']	= 'الإعدادات';
$langmessage['hidegplink']		= 'Hide AktifBoxCms Link';
$langmessage['options']			= 'خيارات';
$langmessage['default']			= 'افتراضي';
$langmessage['index.html exists'] = 'There is an index.html file in your root directory and may prevent AktifBoxCms from displaying.';
$langmessage['Notes']			= 'Notes';



$langmessage['Installation_Was_Successfull']	= 'Installation Was Successfull!';
$langmessage['View_your_web_site']				= 'View your web site';
$langmessage['Log_in_and_start_editing']		= 'Log in and start editing';
$langmessage['User Details']					= 'User Details';
$langmessage['Changing_File_Permissions']		= 'Changing File Permissions';
$langmessage['REFRESH_AFTER_CHANGE']			= 'You may need to change the permssions of the directories that failed in the above section then <a href="">refresh this page</a>.';
$langmessage['MOST_FTP_CLIENTS']				= 'Most FTP clients allow you to change the permissions of files on your server. In <a href="http://fireftp.mozdev.org/">fireftp</a> This can be done by right clicking on the file, selecting "properties" from the menu then setting the permissions appropriately.';
$langmessage['LINUX_CHMOD']						= 'If you are using Unix/Linux, you can use the function <tt>chmod</tt>.';
$langmessage['your_install_directory']			= '--your_install_directory--';


$langmessage['Safe_Mode_Install']				= 'Safe Mode Install';
$langmessage['Installing_in_Safe_Mode']			= 'Installing in Safe Mode';
$langmessage['Safe_Mode_Unavailable']			= 'Sorry, AktifBoxCms will not work on a server when safe_mode is enabled and ftp functions are unavailable.';
$langmessage['Warning']							= 'Warning';
$langmessage['FTP_WARNING']						= 'Your FTP username/password will be saved on the server which could be considered a security risk.';
$langmessage['FTP_INFORMATION']					= 'To work properly in <i>safe_mode</i>, AktifBoxCms needs FTP connection information for your server.';
$langmessage['FTP_Server']						= 'FTP Server';
$langmessage['FTP_Username']					= 'FTP Username';
$langmessage['FTP_Password']					= 'FTP Password';
$langmessage['Permissions_for']					= 'Permissions for <i>%s</i>';
$langmessage['Using_FTP']						= 'Using FTP';
$langmessage['Could_Not_']						= 'Could not %s';
$langmessage['FTP_PERMISSIONS_CHANGED']			= 'File permissions for %s changed.';
$langmessage['Success_continue_below']			= 'Success! ... continue below';
$langmessage['FTP_UNAVAILABLE']					= 'FTP functions are not installed.';
$langmessage['FTP_AVAILABLE']					= 'Found FTP functions.';
$langmessage['FAILED_TO_CONNECT']				= 'Failed to connect to %s.';
$langmessage['CONNECTED_TO']					= 'Connected to %s';
$langmessage['NOT_LOOGED_IN']					= 'Could not log in user  %s';
$langmessage['LOGGED_IN']						= 'User %s logged in.';
$langmessage['ROOT_DIRECTORY_NOT_FOUND']		= 'Could not find the root directory.';
$langmessage['FTP_ROOT']						= 'FTP Root found: %s.';


$langmessage['Admin_Username']					= 'Admin Username';
$langmessage['Admin_Password']					= 'Admin Password';
$langmessage['Repeat_Password']					= 'كرر كلمة السر';
$langmessage['invalid_password']				= 'عفوا ، كلمات السر هي إما فارغة أو لا تتطابق. يرجى المحاولة مرة أخرى';
$langmessage['PASSWORDS_MATCHED']				= 'Passwords matched.';
$langmessage['invalid_username']				= 'اسم المستخدم الخاص بك ينبغي استخدام مزيج من الأحرف الأبجدية الرقمية مع التأكيد اختياري "_" ونقطة "." حرفا';
$langmessage['Username_ok']						= 'Username ok.';
$langmessage['COULD_NOT_SAVE']					= 'Could not save %s';
$langmessage['_SAVED']							= '%s saved.';


$langmessage['image_functions']					= 'Image Functions';
$langmessage['available']						= 'Available';
$langmessage['unavailable']						= 'غير متوفر';
$langmessage['partially_available']				= 'Partially Available';


