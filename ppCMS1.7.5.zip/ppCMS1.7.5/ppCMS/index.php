<?php


//define('gpdebug',true);
//define('gp_indexphp',false);
//define('gptesting',true);
require_once('./include/main.php');
